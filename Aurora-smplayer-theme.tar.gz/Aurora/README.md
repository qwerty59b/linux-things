# Aurora - tema para SMPlayer

Tema para SMPlayer al estilo Breeze Dark de KDE Plasma: iconos de linea
finos (64x64 px, listos para pantallas HiDPI) con los colores de Breeze y
una hoja de estilos (`style.qss`) para menus, barras, deslizadores, botones,
listas y dialogos.

## Instalacion (Arch Linux / KDE)

```bash
mkdir -p ~/.config/smplayer/themes
cp -r Aurora ~/.config/smplayer/themes/
```

Para instalarlo para todos los usuarios, copia la carpeta a
`/usr/share/smplayer/themes/`.

Despues abre SMPlayer y ve a:

**Preferencias -> Interfaz -> Juego de iconos -> Aurora**

y reinicia SMPlayer. El archivo `style.qss` de la misma carpeta se aplica
automaticamente junto con el juego de iconos.

## Contenido

- `*.png`: iconos (reproduccion, volumen, video, subtitulos, preferencias,
  discos, favoritos, etc.). Los nombres coinciden con los que busca SMPlayer;
  cualquier icono que falte se toma del tema por defecto.
- `logo.png`: logotipo de la ventana "Acerca de" (150x150).
- `style.qss`: estilo oscuro (colores, bordes redondeados, deslizadores...).

## Personalizar

- Colores: la paleta es Breeze Dark. Edita `#3daee9` (acento), `#31363b`
  (ventana) y `#232629` (campos y listas) en `style.qss`.
- Iconos: el script `generate_icons.py` (incluido en el paquete) los dibuja
  con Pillow. Cambia los colores `FG`, `ACC`, etc. del principio, o el
  grosor `SW`, y ejecuta:

  ```bash
  python3 generate_icons.py Aurora
  ```

## Nota

No incluyas un archivo `main.css` en la carpeta del tema: SMPlayer lo trata
como un *skin* completo (SkinGUI) y lo muestra en otra lista en lugar de en
"Juego de iconos".
