#!/usr/bin/env python3
"""
Generador del juego de iconos "Aurora" (estilo Breeze Dark de KDE Plasma) para SMPlayer.

Dibuja iconos de línea modernos (rejilla de 24 unidades, trazo redondeado)
con supersampling para obtener bordes suaves, y los exporta a PNG de 64x64.

Uso:  python3 generate_icons.py [directorio_salida]
Requiere: Pillow
"""
import colorsys
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFont

K = 16            # factor de supersampling (unidades -> píxeles)
S = 24            # tamaño de la rejilla
OUT = 64          # tamaño final de los PNG
SW = 1.8          # grosor de trazo por defecto
WS = 0.82         # factor de adelgazado global (aspecto Breeze)
RS = 0.55         # factor de redondeo de esquinas (Breeze es mas recto)

# Colores de Breeze Dark
FG = (239, 240, 241, 255)      # texto  #eff0f1
ACC = (61, 174, 233, 255)      # acento #3daee9
CYAN = (26, 188, 156, 255)     # turquesa #1abc9c
RED = (218, 68, 83, 255)       # negativo #da4453
YEL = (253, 188, 75, 255)      # amarillo #fdbc4b
GRN = (39, 174, 96, 255)       # positivo #27ae60

FONT_CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
]


def load_font(px):
    for path in FONT_CANDIDATES:
        if os.path.exists(path):
            return ImageFont.truetype(path, px)
    return ImageFont.load_default(px)


class Icon:
    def __init__(self):
        self.im = Image.new("RGBA", (S * K, S * K), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    # --- utilidades -------------------------------------------------
    def P(self, p):
        return (p[0] * K, p[1] * K)

    def flip_h(self):
        self.im = self.im.transpose(Image.FLIP_LEFT_RIGHT)
        self.d = ImageDraw.Draw(self.im)

    # --- primitivas -------------------------------------------------
    def line(self, pts, w=SW, c=FG, closed=False):
        w *= WS
        pp = [self.P(p) for p in pts]
        if closed:
            pp = pp + [pp[0]]
        self.d.line(pp, fill=c, width=max(1, int(w * K)), joint="curve")
        r = w * K / 2
        for x, y in pp:
            self.d.ellipse((x - r, y - r, x + r, y + r), fill=c)

    def poly(self, pts, c=FG, rnd=1.2):
        pp = [self.P(p) for p in pts]
        self.d.polygon(pp, fill=c)
        if rnd:
            self.line(pts, w=rnd, c=c, closed=True)

    def circ(self, cx, cy, r, c=FG, w=SW, fill=False):
        w *= WS
        if fill:
            self.d.ellipse(((cx - r) * K, (cy - r) * K, (cx + r) * K, (cy + r) * K), fill=c)
        else:
            ro = r + w / 2
            self.d.ellipse(((cx - ro) * K, (cy - ro) * K, (cx + ro) * K, (cy + ro) * K),
                           outline=c, width=max(1, int(w * K)))

    def ell(self, cx, cy, rx, ry, c=FG, w=SW):
        w *= WS
        self.d.ellipse(((cx - rx - w / 2) * K, (cy - ry - w / 2) * K,
                        (cx + rx + w / 2) * K, (cy + ry + w / 2) * K),
                       outline=c, width=max(1, int(w * K)))

    def arc(self, cx, cy, r, a0, a1, w=SW, c=FG, caps=True):
        w *= WS
        ro = r + w / 2
        self.d.arc(((cx - ro) * K, (cy - ro) * K, (cx + ro) * K, (cy + ro) * K),
                   a0, a1, fill=c, width=max(1, int(w * K)))
        if caps:
            for a in (a0, a1):
                x = cx + r * math.cos(math.radians(a))
                y = cy + r * math.sin(math.radians(a))
                rr = w * K / 2
                self.d.ellipse((x * K - rr, y * K - rr, x * K + rr, y * K + rr), fill=c)

    def rrect(self, x0, y0, x1, y1, r, c=FG, w=SW, fill=False):
        w *= WS
        r *= RS
        if fill:
            self.d.rounded_rectangle((x0 * K, y0 * K, x1 * K, y1 * K), radius=r * K, fill=c)
        else:
            h = w / 2
            self.d.rounded_rectangle(((x0 - h) * K, (y0 - h) * K, (x1 + h) * K, (y1 + h) * K),
                                     radius=(r + h) * K, outline=c, width=max(1, int(w * K)))

    def text(self, s, cx, cy, size, c=FG):
        f = load_font(int(size * K))
        self.d.text((cx * K, cy * K), s, font=f, fill=c, anchor="mm")

    def chevron(self, tip, direction, size=2.6, w=SW, c=FG):
        dx, dy = direction
        n = math.hypot(dx, dy)
        dx, dy = dx / n, dy / n
        px, py = -dy, dx
        a = (tip[0] - dx * size + px * size, tip[1] - dy * size + py * size)
        b = (tip[0] - dx * size - px * size, tip[1] - dy * size - py * size)
        self.line([a, tip, b], w=w, c=c)

    def save(self, path, size=OUT):
        self.im.resize((size, size), Image.LANCZOS).save(path)


def bez(p0, p1, p2, p3, n=24):
    pts = []
    for i in range(n + 1):
        t = i / n
        x = (1 - t) ** 3 * p0[0] + 3 * (1 - t) ** 2 * t * p1[0] + 3 * (1 - t) * t ** 2 * p2[0] + t ** 3 * p3[0]
        y = (1 - t) ** 3 * p0[1] + 3 * (1 - t) ** 2 * t * p1[1] + 3 * (1 - t) * t ** 2 * p2[1] + t ** 3 * p3[1]
        pts.append((x, y))
    return pts


# ======================================================================
#  Dibujos
# ======================================================================
def d_play(i):
    i.poly([(8.6, 5.9), (8.6, 18.1), (18.6, 12)], rnd=1.6)


def d_play_pause(i):
    i.poly([(4.8, 5.6), (4.8, 18.4), (13.2, 12)], rnd=1.4)
    i.rrect(15.2, 5.5, 17, 18.5, 0.9, fill=True)
    i.rrect(18.2, 5.5, 20, 18.5, 0.9, fill=True)


def d_pause(i):
    i.rrect(6.6, 5, 10.2, 19, 1.6, fill=True)
    i.rrect(13.8, 5, 17.4, 19, 1.6, fill=True)


def d_stop(i):
    i.rrect(6, 6, 18, 18, 2.6, fill=True)


def d_previous(i):
    i.rrect(5.2, 5.5, 7.2, 18.5, 1, fill=True)
    i.poly([(18.6, 6), (18.6, 18), (9.4, 12)], rnd=1.4)


def d_next(i):
    i.rrect(16.8, 5.5, 18.8, 18.5, 1, fill=True)
    i.poly([(5.4, 6), (5.4, 18), (14.6, 12)], rnd=1.4)


def _skip(i, label, forward, size):
    cx, cy, r = 12, 12.6, 8.3
    # arco de rebobinado (sentido antihorario) con la punta arriba;
    # para avanzar se refleja horizontalmente antes de escribir el texto
    i.arc(cx, cy, r, 290, 200, w=1.7)
    th = math.radians(290)
    tip = (cx + r * math.cos(th) + 0.4, cy + r * math.sin(th))
    i.chevron(tip, (math.sin(th), -math.cos(th)), size=2.5, w=1.7)
    if forward:
        i.flip_h()
    i.text(label, 12, 13.2, size)


def d_rewind10s(i): _skip(i, "10", False, 7.4)
def d_forward10s(i): _skip(i, "10", True, 7.4)
def d_rewind1m(i): _skip(i, "1m", False, 6.8)
def d_forward1m(i): _skip(i, "1m", True, 6.8)
def d_rewind10m(i): _skip(i, "10m", False, 5.8)
def d_forward10m(i): _skip(i, "10m", True, 5.8)


def _speaker(i, c=FG):
    i.poly([(4, 9.6), (7.8, 9.6), (12.4, 5.6), (12.4, 18.4), (7.8, 14.4), (4, 14.4)], c=c, rnd=1.2)


def d_volume(i):
    _speaker(i)
    i.arc(12.4, 12, 4.4, -48, 48, w=1.7)
    i.arc(12.4, 12, 8.0, -48, 48, w=1.7)


def d_mute(i):
    _speaker(i)
    i.line([(16.2, 9.4), (21, 14.6)], w=1.8)
    i.line([(21, 9.4), (16.2, 14.6)], w=1.8)


def d_fullscreen(i):
    i.line([(4, 9), (4, 4), (9, 4)])
    i.line([(15, 4), (20, 4), (20, 9)])
    i.line([(20, 15), (20, 20), (15, 20)])
    i.line([(9, 20), (4, 20), (4, 15)])


def d_resize_window(i):
    i.rrect(3.5, 4.5, 20.5, 19.5, 2.6)
    i.line([(11, 9), (15, 9), (15, 13)])
    i.line([(13, 15), (9, 15), (9, 11)])


def d_folder(i):
    i.line([(3.5, 6.5), (9, 6.5), (11, 8.8), (20.5, 8.8), (20.5, 18.5), (3.5, 18.5)], closed=True)


def d_folder_open(i):
    i.line([(3.5, 18.5), (3.5, 5.8), (9, 5.8), (11, 8), (18.5, 8), (18.5, 10.2)])
    i.line([(3.5, 18.5), (5.8, 10.4), (21.5, 10.4), (19.2, 18.5)], closed=True)


def d_url(i):
    i.circ(12, 12, 8.6)
    i.ell(12, 12, 3.8, 8.6, w=1.5)
    i.line([(3.4, 12), (20.6, 12)], w=1.5)
    i.line([(5, 7.6), (19, 7.6)], w=1.4)
    i.line([(5, 16.4), (19, 16.4)], w=1.4)


def d_playlist(i):
    i.line([(4, 7), (20, 7)])
    i.line([(4, 12), (12, 12)])
    i.line([(4, 17), (12, 17)])
    i.poly([(15, 13), (15, 20), (21, 16.5)], rnd=1.2)


def d_open_playlist(i):
    i.line([(4, 7), (20, 7)])
    i.line([(4, 12), (20, 12)])
    i.line([(4, 17), (11, 17)])
    i.line([(17, 14), (17, 20)])
    i.line([(14, 17), (20, 17)])


def d_repeat(i):
    i.line([(4.6, 11), (4.6, 9.6), (7.2, 7), (19, 7)])
    i.chevron((19.4, 7), (1, 0), size=2.6)
    i.line([(19.4, 13), (19.4, 14.4), (16.8, 17), (5, 17)])
    i.chevron((4.6, 17), (-1, 0), size=2.6)


def d_shuffle(i):
    i.line([(3.5, 7), (8, 7), (16, 17), (19.6, 17)])
    i.line([(3.5, 17), (8, 17), (10.2, 14.2)])
    i.line([(13.8, 9.8), (16, 7), (19.6, 7)])
    i.chevron((20.4, 7), (1, 0), size=2.6)
    i.chevron((20.4, 17), (1, 0), size=2.6)


def d_screenshot(i):
    i.rrect(3, 7, 21, 19.5, 3)
    i.line([(8, 7), (9.4, 4.8), (14.6, 4.8), (16, 7)])
    i.circ(12, 13.2, 3.4)


def d_image(i):
    i.rrect(3.5, 5, 20.5, 19, 2.8)
    i.circ(8.6, 9.8, 1.7, fill=True)
    i.line([(4.2, 17.2), (10, 12.2), (13.6, 15.6), (16.2, 13.4), (19.8, 17.2)], w=1.6)


def d_gear(i):
    pts = []
    for k in range(8):
        a = k * 45
        for r, da in ((6.6, -17), (8.9, -10), (8.9, 10), (6.6, 17)):
            ang = math.radians(a + da - 90)
            pts.append((12 + r * math.cos(ang), 12 + r * math.sin(ang)))
    i.line(pts, w=1.6, closed=True)
    i.circ(12, 12, 2.8, w=1.7)


def d_sliders_h(i):
    for y, kx in ((7, 9), (12, 15.5), (17, 8)):
        i.line([(4, y), (kx - 3, y)])
        i.line([(kx + 3, y), (20, y)])
        i.circ(kx, y, 2.2, w=1.7)


def d_sliders_v(i):
    for x, ky in ((6, 15), (12, 8.5), (18, 12.5)):
        i.line([(x, 4), (x, ky - 3)])
        i.line([(x, ky + 3), (x, 20)])
        i.circ(x, ky, 2.2, w=1.7)


def d_note(i):
    i.circ(7.6, 17.4, 2.7, fill=True)
    i.circ(16.6, 15.4, 2.7, fill=True)
    i.line([(10.3, 17.4), (10.3, 6.8)], w=1.7)
    i.line([(19.3, 15.4), (19.3, 4.8)], w=1.7)
    i.line([(10.3, 6.8), (19.3, 4.8)], w=2.4)


def d_subtitles(i):
    i.rrect(3, 5, 21, 19, 3)
    i.line([(6.5, 11), (9.6, 11)])
    i.line([(12.2, 11), (17.5, 11)])
    i.line([(6.5, 15), (12.8, 15)])
    i.line([(15.4, 15), (17.5, 15)])


def d_subtitles2(i):
    d_subtitles(i)
    i.circ(18.2, 17.6, 3.4, c=(49, 54, 59, 255), fill=True)
    i.text("2", 18.2, 17.8, 5.4, c=ACC)


def d_video(i):
    i.rrect(3, 5, 21, 19, 3.6)
    i.poly([(10.2, 9.2), (10.2, 14.8), (15, 12)], rnd=1.2)


def d_monitor(i):
    i.rrect(3, 4.5, 21, 16.5, 2.4)
    i.line([(9, 20), (15, 20)])
    i.line([(12, 16.5), (12, 20)])


def d_osd(i):
    i.rrect(3, 4.5, 21, 19.5, 2.8)
    i.line([(7, 10), (17, 10)])
    i.line([(7, 14.2), (13, 14.2)])


def d_tv(i):
    i.rrect(3, 7.5, 21, 20, 2.6)
    i.line([(8.5, 3.8), (12, 7.5), (15.5, 3.8)])


def d_speed(i):
    i.arc(12, 14, 8.2, 180, 360, w=1.8)
    i.line([(12, 14), (16.4, 9.6)], w=1.9)
    i.circ(12, 14, 1.6, fill=True)
    i.line([(3.8, 14), (3.8, 14.1)])
    i.line([(20.2, 14), (20.2, 14.1)])


def d_aspect(i):
    i.rrect(3, 6.5, 21, 17.5, 2.4)
    i.line([(7, 12), (17, 12)])
    i.chevron((6.4, 12), (-1, 0), size=2.2)
    i.chevron((17.6, 12), (1, 0), size=2.2)


def d_rotate(i):
    cx, cy, r = 12, 12, 7.6
    i.arc(cx, cy, r, 330, 250, w=1.8)
    th = math.radians(250)
    tip = (cx + r * math.cos(th) - 0.3, cy + r * math.sin(th))
    i.chevron(tip, (-math.sin(th), math.cos(th)), size=2.6, w=1.8)


def d_flip(i):
    i.line([(10, 6), (10, 18), (3.6, 18)], closed=True)
    i.poly([(14, 6), (14, 18), (20.4, 18)], rnd=1.2)
    for y in (4, 9.5, 15):
        i.line([(12, y), (12, y + 2.2)], w=1.5)


def d_info(i):
    i.circ(12, 12, 8.6)
    i.circ(12, 8.2, 1.15, fill=True)
    i.line([(12, 11.2), (12, 16.6)])


def d_help(i):
    i.circ(12, 12, 8.6)
    i.text("?", 12, 12.6, 11)


def _star_pts(cx=12, cy=12.9, ro=9.2, ri=4.2):
    pts = []
    for k in range(10):
        r = ro if k % 2 == 0 else ri
        a = math.radians(-90 + k * 36)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def d_favorite(i):
    i.poly(_star_pts(), c=YEL, rnd=1.4)


def d_favorite_add(i):
    i.line(_star_pts(11, 12.9, 8.4, 3.9), c=YEL, closed=True)
    i.line([(19, 14.5), (19, 20.5)], c=FG, w=1.7)
    i.line([(16, 17.5), (22, 17.5)], c=FG, w=1.7)


def d_favorite_folder(i):
    d_folder(i)
    i.poly(_star_pts(12, 14, 3.9, 1.8), c=YEL, rnd=0.7)


def d_bookmarks(i):
    i.line([(7, 4), (17, 4), (17, 20), (12, 16), (7, 20)], closed=True)


def d_add_bookmark(i):
    i.line([(5.5, 4), (15.5, 4), (15.5, 20), (10.5, 16), (5.5, 20)], closed=True)
    i.line([(19, 5.5), (19, 11.5)], w=1.7)
    i.line([(16, 8.5), (22, 8.5)], w=1.7)


def d_clock(i):
    i.circ(12, 12, 8.6)
    i.line([(12, 7), (12, 12), (15.6, 14.2)])


def d_record(i):
    i.circ(12, 12, 8.6, c=RED, w=1.6)
    i.circ(12, 12, 4.6, c=RED, fill=True)


def d_close(i):
    i.line([(6, 6), (18, 18)], w=2)
    i.line([(18, 6), (6, 18)], w=2)


def d_exit(i):
    i.line([(10.5, 4.5), (5, 4.5), (5, 19.5), (10.5, 19.5)])
    i.line([(9.5, 12), (20, 12)])
    i.chevron((20.6, 12), (1, 0), size=3)


def d_power(i):
    i.arc(12, 13, 7.6, 300, 240, w=1.9)
    i.line([(12, 4), (12, 12)], w=1.9)


def d_up(i):
    i.line([(6, 15), (12, 9), (18, 15)], w=2)


def d_down(i):
    i.line([(6, 9), (12, 15), (18, 9)], w=2)


def d_plus(i):
    i.line([(12, 5), (12, 19)], w=2)
    i.line([(5, 12), (19, 12)], w=2)


def d_minus(i):
    i.line([(5, 12), (19, 12)], w=2)


def d_check(i):
    i.line([(5, 12.6), (10, 17.4), (19, 7)], c=GRN, w=2.3)


def d_check_white(i):
    i.line([(5, 12.6), (10, 17.4), (19, 7)], c=FG, w=2.3)


def d_warning(i):
    i.line([(12, 4.2), (21, 19.6), (3, 19.6)], c=YEL, closed=True, w=1.8)
    i.line([(12, 10), (12, 14.6)], c=YEL, w=1.8)
    i.circ(12, 17.1, 0.95, c=YEL, fill=True)


def d_trash(i):
    i.line([(4.5, 7), (19.5, 7)])
    i.line([(9.5, 7), (9.5, 4.5), (14.5, 4.5), (14.5, 7)])
    i.line([(6.4, 7), (7.4, 19.5), (16.6, 19.5), (17.6, 7)])
    i.line([(10.4, 10.5), (10.4, 16.5)], w=1.5)
    i.line([(13.6, 10.5), (13.6, 16.5)], w=1.5)


def d_save(i):
    i.line([(4.5, 4.5), (16.5, 4.5), (19.5, 7.5), (19.5, 19.5), (4.5, 19.5)], closed=True)
    i.line([(8, 4.5), (8, 9), (15, 9), (15, 4.5)], w=1.6)
    i.line([(7.5, 19.5), (7.5, 13.5), (16.5, 13.5), (16.5, 19.5)], w=1.6)


def d_find(i):
    i.circ(10.5, 10.5, 6.2)
    i.line([(15.2, 15.2), (20, 20)], w=2.2)


def d_download(i):
    i.line([(12, 4), (12, 15)])
    i.line([(7.4, 10.6), (12, 15.2), (16.6, 10.6)])
    i.line([(5, 19.5), (19, 19.5)])


def d_clear_left(i):
    i.line([(8.4, 6), (20, 6), (20, 18), (8.4, 18), (3.6, 12)], closed=True)
    i.line([(11.8, 9.6), (16.4, 14.4)], w=1.6)
    i.line([(16.4, 9.6), (11.8, 14.4)], w=1.6)


def d_copy(i):
    i.rrect(8.5, 8.5, 19.5, 19.5, 2.2)
    i.line([(8.5, 15.5), (6.5, 15.5), (4.5, 13.5), (4.5, 6.5), (6.5, 4.5), (13.5, 4.5), (15.5, 6.5), (15.5, 8.5)])


def d_doc(i):
    i.line([(6.5, 3.5), (14, 3.5), (18.5, 8), (18.5, 20.5), (6.5, 20.5)], closed=True)
    i.line([(14, 3.5), (14, 8), (18.5, 8)], w=1.6)
    i.line([(9.5, 13), (15.5, 13)], w=1.6)
    i.line([(9.5, 16.5), (15.5, 16.5)], w=1.6)


def d_doc_check(i):
    i.line([(6.5, 3.5), (14, 3.5), (18.5, 8), (18.5, 20.5), (6.5, 20.5)], closed=True)
    i.line([(14, 3.5), (14, 8), (18.5, 8)], w=1.6)
    i.line([(9.6, 14.4), (11.8, 16.6), (15.6, 12.2)], c=GRN, w=1.9)


def d_compact(i):
    i.rrect(4, 6, 20, 18, 2.4)
    i.line([(4, 10), (20, 10)], w=1.6)


def d_ontop(i):
    i.rrect(8, 4, 20, 14, 2.4, c=ACC)
    i.rrect(4, 10, 16, 20, 2.4)


def d_brightness(i):
    i.circ(12, 12, 3.9)
    for k in range(8):
        a = math.radians(k * 45)
        i.line([(12 + 6.8 * math.cos(a), 12 + 6.8 * math.sin(a)),
                (12 + 9 * math.cos(a), 12 + 9 * math.sin(a))], w=1.6)


def d_contrast(i):
    i.circ(12, 12, 8.4)
    i.d.pieslice(((12 - 8.4) * K, (12 - 8.4) * K, (12 + 8.4) * K, (12 + 8.4) * K), 270, 90, fill=FG)


def d_hue(i):
    for k in range(72):
        r, g, b = colorsys.hsv_to_rgb(k / 72, 0.62, 1.0)
        i.arc(12, 12, 7.8, k * 5 - 1, (k + 1) * 5 + 1, w=2.8, c=(int(r * 255), int(g * 255), int(b * 255), 255), caps=False)


def d_saturation(i):
    pts = bez((12, 3.6), (14, 7), (18.2, 9.6), (18.2, 14.2))
    for a in range(0, 181, 10):
        t = math.radians(a)
        pts.append((12 + 6.2 * math.cos(t), 14.2 + 6.2 * math.sin(t)))
    pts += bez((5.8, 14.2), (5.8, 9.6), (10, 7), (12, 3.6))
    i.line(pts, closed=True, w=1.7)


def d_gamma(i):
    i.circ(12, 12, 8.6)
    i.text("γ", 12, 12.6, 10.5)


def d_pref_gui(i):
    i.rrect(3, 4.5, 21, 19.5, 2.8)
    i.line([(3, 9), (21, 9)], w=1.5)
    i.circ(6.4, 6.8, 0.7, fill=True)
    i.circ(9, 6.8, 0.7, fill=True)


def d_keyboard(i):
    i.rrect(2.6, 6.2, 21.4, 17.8, 2.6)
    for y in (10.2, 13.2):
        for x in (6, 9.4, 12.8, 16.2):
            i.circ(x, y, 0.75, fill=True)
    i.line([(8, 15.4), (16, 15.4)], w=1.5)


def d_mouse(i):
    i.rrect(6.6, 3.5, 17.4, 20.5, 5.4)
    i.line([(12, 3.8), (12, 10)], w=1.5)
    i.line([(6.8, 10), (17.2, 10)], w=1.5)


def _disc(i, c):
    i.circ(12, 12, 8.8, c=c, w=1.8)
    i.circ(12, 12, 2.4, c=c, w=1.7)
    i.arc(12, 12, 5.8, 200, 250, w=1.5, c=c)


def d_disc(i): _disc(i, FG)
def d_disc_dvd(i): _disc(i, ACC)
def d_disc_bd(i): _disc(i, CYAN)
def d_disc_vcd(i): _disc(i, GRN)
def d_disc_cd(i): _disc(i, YEL)


def d_unknown(i):
    i.rrect(4, 4, 20, 20, 4, w=1.8)
    i.text("?", 12, 12.6, 10)


def d_menu(i):
    for y in (7, 12, 17):
        i.line([(4, y), (20, y)], w=2)


def d_share(i):
    for (x, y) in ((6.4, 12), (17.6, 5.8), (17.6, 18.2)):
        i.circ(x, y, 2.6, fill=True)
    i.line([(6.4, 12), (17.6, 5.8)], w=1.6)
    i.line([(6.4, 12), (17.6, 18.2)], w=1.6)


def d_stereo(i):
    i.circ(9.4, 12, 6.2)
    i.circ(14.6, 12, 6.2, c=ACC)


def d_tablet(i):
    i.rrect(6, 3.5, 18, 20.5, 2.8)
    i.circ(12, 17.8, 0.9, fill=True)


def d_cast(i):
    i.line([(3.4, 8), (3.4, 6.5), (5, 5), (19, 5), (20.6, 6.5), (20.6, 17.5), (19, 19), (14, 19)])
    i.arc(3, 19.4, 4.6, 270, 360, w=1.7)
    i.arc(3, 19.4, 8.6, 270, 360, w=1.7)
    i.circ(3.6, 19.2, 1.1, fill=True)


def d_radio(i):
    i.rrect(3, 8, 21, 20, 2.8)
    i.line([(7, 8), (17.5, 3.8)])
    i.circ(16.2, 14, 2.6)
    i.line([(6.6, 12.6), (11.4, 12.6)], w=1.6)
    i.line([(6.6, 16.2), (11.4, 16.2)], w=1.6)


def d_chapter(i):
    for y in (7, 12, 17):
        i.circ(5, y, 1.1, fill=True)
        i.line([(9, y), (20, y)])


def d_marker_a(i):
    i.circ(12, 12, 8.6, c=ACC)
    i.text("A", 12, 12.6, 9.6, c=ACC)


def d_marker_b(i):
    i.circ(12, 12, 8.6, c=ACC)
    i.text("B", 12, 12.6, 9.6, c=ACC)


def d_users(i):
    i.circ(9.4, 8.6, 3.2)
    i.arc(9.4, 20, 6.2, 200, 340, w=1.8)
    i.circ(17, 9.6, 2.6, w=1.6)
    i.arc(17, 20, 4.6, 215, 325, w=1.6)


def d_heart(i):
    pts = bez((12, 20), (3, 14), (3, 6), (8, 5.4)) + bez((8, 5.4), (10, 5), (11.4, 6), (12, 7.6)) \
        + bez((12, 7.6), (12.6, 6), (14, 5), (16, 5.4)) + bez((16, 5.4), (21, 6), (21, 14), (12, 20))
    i.poly(pts, c=RED, rnd=1.0)


def d_paypal(i):
    d_heart(i)


# ======================================================================
#  Mapa nombre -> dibujo (nombres que SMPlayer busca)
# ======================================================================
ICONS = {
    # reproducción
    "play": d_play, "pause": d_pause, "play_pause": d_play_pause, "stop": d_stop,
    "previous": d_previous, "next": d_next,
    "rewind10s": d_rewind10s, "rewind1m": d_rewind1m, "rewind10m": d_rewind10m,
    "forward10s": d_forward10s, "forward1m": d_forward1m, "forward10m": d_forward10m,
    "repeat": d_repeat, "shuffle": d_shuffle,
    # audio
    "volume": d_volume, "mute": d_mute, "speaker": d_volume,
    "audio_track": d_note, "type_audio": d_note, "send_audio": d_note,
    "equalizer": d_sliders_v, "audio_equalizer": d_sliders_v, "audio_filters": d_sliders_v,
    "audio_channels": d_stereo, "stereo": d_stereo, "stereo_mode": d_stereo, "stereo3d": d_stereo,
    # video
    "fullscreen": d_fullscreen, "resize_window": d_resize_window, "video_size": d_resize_window,
    "video_track": d_video, "type_video": d_video, "video_filters": d_sliders_h,
    "aspect": d_aspect, "next_aspect": d_aspect, "rotate": d_rotate, "flip": d_flip, "mirror": d_flip,
    "brightness": d_brightness, "contrast": d_contrast, "hue": d_hue,
    "saturation": d_saturation, "gamma": d_gamma, "speed": d_speed,
    "screenshot": d_screenshot, "screenshots": d_image, "video_preview": d_image,
    "monitor": d_monitor, "osd": d_osd, "compact": d_compact, "ontop": d_ontop,
    "tablet_mode": d_tablet, "tabletmode": d_tablet,
    # subtítulos
    "sub": d_subtitles, "secondary_sub": d_subtitles2, "download_subs": d_download,
    # abrir
    "open": d_folder, "open_directory": d_folder, "show_config": d_folder,
    "openfolder": d_folder_open, "folder_open": d_folder_open,
    "url": d_url, "type_url": d_url, "url_big": d_url,
    "open_playlist": d_open_playlist, "playlist": d_playlist, "open_tv": d_tv, "type_tv": d_tv,
    "open_radio": d_radio, "open_favorites": d_favorite_folder, "favorite-folder": d_favorite_folder,
    "open_disc": d_disc, "dvd": d_disc_dvd, "type_dvd": d_disc_dvd, "dvd_drive": d_disc_dvd, "dvd_hd": d_disc_dvd,
    "bluray": d_disc_bd, "type_bluray": d_disc_bd, "bluray_drive": d_disc_bd,
    "vcd": d_disc_vcd, "type_vcd": d_disc_vcd,
    "cdda": d_disc_cd, "type_cdda": d_disc_cd, "cdrom_drive": d_disc_cd, "cdrom": d_disc_cd,
    "type_unknown": d_unknown,
    # listas y favoritos
    "favorite": d_favorite, "favorite-add": d_favorite_add,
    "bookmarks": d_bookmarks, "add_bookmark": d_add_bookmark, "recents": d_clock,
    "chapter": d_chapter, "a_marker": d_marker_a, "b_marker": d_marker_b,
    # acciones
    "record": d_record, "refresh": d_rotate, "close": d_close, "exit": d_exit, "shutdown": d_power,
    "qss_check": d_check_white, "up": d_up, "down": d_down, "plus": d_plus, "minus": d_minus, "check": d_check, "ok": d_check,
    "warning": d_warning, "conflict": d_warning, "crash": d_warning,
    "delete": d_trash, "trash": d_trash, "save": d_save, "find": d_find, "download": d_download,
    "clear_left": d_clear_left, "copy": d_copy, "logs": d_doc, "license": d_doc,
    "info": d_info, "cl_help": d_help, "faq": d_help, "guide": d_help,
    "share": d_share, "send_to_screen": d_share, "cast": d_cast, "chromecast": d_cast,
    "tubebrowser": d_video, "quick_access_menu": d_menu,
    "contributors": d_users, "translators": d_users, "donate": d_heart, "donate_big": d_heart, "paypal": d_heart,
    # preferencias
    "prefs": d_gear, "pref_general": d_gear, "pref_advanced": d_sliders_h, "pref_gui": d_pref_gui,
    "pref_devices": d_volume, "input_devices": d_keyboard, "keyboard": d_keyboard, "mouse": d_mouse,
    "pref_network": d_url, "pref_performance": d_speed, "pref_playlist": d_playlist,
    "pref_subtitles": d_subtitles, "pref_updates": d_rotate, "check_updates": d_rotate,
    "update_youtube": d_rotate, "pref_associations": d_doc_check, "pref_tv": d_tv,
}


def make_logo(path, size=150):
    """Logotipo de la pantalla 'Acerca de': cuadrado redondeado degradado + play."""
    big = size * 6
    img = Image.new("RGBA", (big, big), (0, 0, 0, 0))
    grad = Image.new("RGBA", (big, big))
    gp = grad.load()
    c0, c1 = (61, 174, 233), (29, 153, 243)
    for y in range(big):
        for x in range(big):
            t = (x + y) / (2 * big)
            gp[x, y] = (int(c0[0] + (c1[0] - c0[0]) * t), int(c0[1] + (c1[1] - c0[1]) * t),
                        int(c0[2] + (c1[2] - c0[2]) * t), 255)
    mask = Image.new("L", (big, big), 0)
    ImageDraw.Draw(mask).rounded_rectangle((big * 0.06, big * 0.06, big * 0.94, big * 0.94),
                                           radius=big * 0.12, fill=255)
    img.paste(grad, (0, 0), mask)
    d = ImageDraw.Draw(img)
    u = big / 24
    pts = [(9 * u, 6.4 * u), (9 * u, 17.6 * u), (18.4 * u, 12 * u)]
    d.polygon(pts, fill=(255, 255, 255, 255))
    d.line(pts + [pts[0]], fill=(255, 255, 255, 255), width=int(1.6 * u), joint="curve")
    for x, y in pts:
        r = 0.8 * u
        d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 255, 255, 255))
    img.resize((size, size), Image.LANCZOS).save(path)


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "Aurora"
    os.makedirs(out, exist_ok=True)
    for name, fn in ICONS.items():
        ic = Icon()
        fn(ic)
        ic.save(os.path.join(out, name + ".png"))
    make_logo(os.path.join(out, "logo.png"))
    print("%d iconos generados en %s" % (len(ICONS) + 1, out))


if __name__ == "__main__":
    main()
